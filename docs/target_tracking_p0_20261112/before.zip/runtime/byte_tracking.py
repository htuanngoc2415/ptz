"""ByteTrack motion association; native IDs are never treated as identity evidence."""
from types import SimpleNamespace
import time
from pathlib import Path
from telemetry import latency
from ai.reid_target import iou
import numpy as np
from ultralytics.trackers.byte_tracker import BYTETracker, STrack


class Detections:
    def __init__(self, rows):
        self.rows = rows
        self.conf = rows[:, 4]
        self.cls = np.zeros(len(rows))
        self.xyxy = rows[:, :4]
        self.xywh = self.xyxy.copy()
        self.xywh[:, :2] = (self.xyxy[:, :2] + self.xyxy[:, 2:]) / 2
        self.xywh[:, 2:] -= self.xyxy[:, :2]
    def __len__(self):
        return len(self.rows)
    def __getitem__(self, index):
        return Detections(self.rows[index])


class IndexedByteTracker(BYTETracker):
    def init_track(self, results, img=None):
        # Preserve original indexes through ByteTrack's high/low score partitions.
        return [STrack(np.r_[box, row[5]], score, 0)
                for box, row, score in zip(results.xywh, results.rows, results.conf)]


class ByteTrackPersonTracker:
    def __init__(self, cfg):
        self.cfg = cfg
        self.tracker = IndexedByteTracker(SimpleNamespace(
            track_high_thresh=cfg.PERSON_CONF_THRESHOLD,
            track_low_thresh=cfg.BYTE_TRACK_LOW_THRESHOLD,
            new_track_thresh=cfg.PERSON_CONF_THRESHOLD,
            track_buffer=round(30 * cfg.REID_LOST_GRACE_SEC),
            match_thresh=.8, fuse_score=False), frame_rate=cfg.AI_MAX_FPS)
        self.ids = {}
        self.next_id = 0
        self.last_received = None
        self.last_diagnostic = float("-inf")

    def reset(self):
        self.tracker.reset()
        self.ids.clear()
        self.last_received = None

    def update(self, persons, received, frame=None, frame_id=None):
        if self.last_received is not None:
            if received <= self.last_received:
                return []
            if received-self.last_received > self.cfg.REID_LOST_GRACE_SEC:
                self.reset()
        self.last_received = received
        # Repeating the SAME dict is provably the same observation, unlike two
        # distinct boxes with high IoU. Never merge distinct detections by geometry.
        unique, seen = [], set()
        for person in persons:
            if id(person) not in seen:
                seen.add(id(person))
                unique.append(person)
            else:
                latency.profiler.count('repeated_detection_aliases')
        persons = unique
        rows = np.asarray([[*p['bbox'], p.get('confidence', 1.), i]
                           for i, p in enumerate(persons)], dtype=np.float32).reshape(-1, 6)
        output = []
        native_rows = self.tracker.update(Detections(rows))
        for track in native_rows:
            native, index = int(track[4]), int(track[-1])
            if native not in self.ids:
                self.next_id += 1
                self.ids[native] = self.next_id
            if not 0 <= index < len(persons):
                raise ValueError('ByteTrack returned invalid source detection index')
            person = dict(persons[index])
            person['track_id'] = self.ids[native]
            output.append(person)
        self._diagnose(persons, output, native_rows, received, frame_id, frame)
        return output

    def _diagnose(self, detections, output, native_rows, received, frame_id, frame):
        pairs = []
        for i, a in enumerate(output):
            for b in output[i+1:]:
                x,y = a['bbox'], b['bbox']
                intersection = max(0,min(x[2],y[2])-max(x[0],y[0]))*max(0,min(x[3],y[3])-max(x[1],y[1]))
                overlap = intersection/max(1,min((x[2]-x[0])*(x[3]-x[1]),(y[2]-y[0])*(y[3]-y[1])))
                if overlap >= self.cfg.REID_CROSSING_OVERLAP:
                    pairs.append(dict(ids=[a['track_id'],b['track_id']], iou=iou(x,y), overlap_min_area=overlap))
        if not pairs or received-self.last_diagnostic < self.cfg.TRACK_DIAGNOSTICS_INTERVAL:
            return
        self.last_diagnostic = received
        active = {t.track_id:t for t in self.tracker.tracked_stracks}
        tracks = []
        for row in native_rows:
            t = active.get(int(row[4]))
            tracks.append(dict(tracker_id=self.ids[int(row[4])], native_id=int(row[4]),
                detection_index=int(row[-1]), predicted_updated_bbox=row[:4].tolist(),
                observed_bbox=detections[int(row[-1])]['bbox'],
                confidence=float(row[5]), state=str(t.state) if t else None,
                age_updates=self.tracker.frame_id-t.start_frame+1 if t else None,
                updates_since_observed=self.tracker.frame_id-t.frame_id if t else None,
                last_observation_timestamp=received, reid_evidence=None))
        latency.profiler.event('TRACKER_OVERLAP_DIAGNOSTICS', frame_id=frame_id,
            observation_timestamp=received, detections=[dict(index=i,bbox=p['bbox'],confidence=p.get('confidence')) for i,p in enumerate(detections)],
            tracks=tracks, pairs=pairs,
            lost_native_ids=[t.track_id for t in self.tracker.lost_stracks],
            removed_native_ids=[t.track_id for t in self.tracker.removed_stracks[-20:]], reason='UNRESOLVED_OVERLAP_NOT_PROVEN_DUPLICATE')
        if getattr(self.cfg, 'TRACK_SNAPSHOT_ENABLED', False) and frame is not None:
            try:
                import cv2
                directory = Path(self.cfg.TRACK_SNAPSHOT_DIRECTORY)
                directory.mkdir(parents=True, exist_ok=True)
                limit = max(1, min(100, self.cfg.TRACK_SNAPSHOT_MAX_FILES))
                existing = sorted(directory.glob('overlap_*.jpg'))
                for old in existing[:max(0,len(existing)-limit+1)]:
                    old.unlink()
                h,w = frame.shape[:2]
                scale = min(1.,960/max(h,w))
                snapshot = cv2.resize(frame, (max(1,int(w*scale)),max(1,int(h*scale))))
                cv2.imwrite(str(directory/f'overlap_{time.monotonic_ns()}.jpg'),snapshot,[cv2.IMWRITE_JPEG_QUALITY,75])
            except (OSError, ValueError, cv2.error) as exc:
                latency.profiler.event('TRACKER_SNAPSHOT_FAILED', error_type=type(exc).__name__)
