"""Fresh, identity-authorized body centering using short serialized motor pulses."""
import math
import threading
import time
from telemetry import latency


class AutoPanTiltController:
    def __init__(self, ptz, orchestrator, cfg, status=lambda message: None):
        self.ptz, self.orchestrator, self.cfg, self.status = ptz, orchestrator, cfg, status
        self.enabled = bool(cfg.AUTO_PAN_TILT_ENABLED and getattr(ptz, 'supports_pan_tilt', False))
        self.session_valid = lambda session, track: False
        self._condition = threading.Condition(threading.RLock())
        self._latest = None
        self._closed = False
        self._axis = None
        self._ready_after = 0.
        self._fault = False
        self.busy = False
        self.ptz.pan_tilt_intent_valid = self.validate_intent
        self._thread = threading.Thread(target=self._run, name='auto-pan-tilt', daemon=True)
        self._thread.start()

    def set_enabled(self, enabled):
        with self._condition:
            self.enabled = bool(enabled and getattr(self.ptz, 'supports_pan_tilt', False) and not self._fault)
            self._latest = None
            self._axis = None
            self._condition.notify_all()

    def cancel(self):
        with self._condition:
            self._latest = None
            self._axis = None
            self._condition.notify_all()

    def _direction(self, box, shape):
        h, w = shape[:2]
        if h <= 0 or w <= 0 or len(box) != 4 or not all(math.isfinite(v) for v in box):
            return None
        x1,y1,x2,y2 = box
        if x2 <= x1 or y2 <= y1 or x2 <= 0 or y2 <= 0 or x1 >= w or y1 >= h:
            return None
        dx, dy = ((x1+x2)/2-w/2)/w, ((y1+y2)/2-h/2)/h
        errors = {'pan': dx, 'tilt': dy}
        eligible = {axis: error for axis, error in errors.items()
                    if abs(error) > (self.cfg.AUTO_PAN_TILT_RELEASE if axis == self._axis
                                     else self.cfg.AUTO_PAN_TILT_DEADZONE)}
        if not eligible:
            self._axis = None
            return None
        axis = max(eligible, key=lambda key: abs(eligible[key]))
        self._axis = axis
        error = eligible[axis]
        sign = self.cfg.AUTO_PAN_SIGN if axis == 'pan' else self.cfg.AUTO_TILT_SIGN
        command = ('pan_right' if error*sign > 0 else 'pan_left') if axis == 'pan' else (
                   'tilt_down' if error*sign > 0 else 'tilt_up')
        speed = min(self.cfg.AUTO_PAN_TILT_MAX_SPEED, max(1, 1+int(abs(error)*6)))
        return command, speed

    def submit(self, person, shape, received, session, track):
        with self._condition:
            now = time.monotonic()
            if (not self.enabled or self._closed or self._fault or person is None or not session
                    or not 0 <= now-received <= self.cfg.MAX_CONTROL_OBSERVATION_AGE
                    or not self.session_valid(session, track)):
                self.cancel()
                return False
            direction = self._direction(person['bbox'], shape)
            self._latest = (received, session, track, direction) if direction else None
            self._condition.notify_all()
            return direction is not None

    def validate_intent(self, fields):
        with self._condition:
            item = self._latest
            now = time.monotonic()
            return bool(self.enabled and not self._closed and not self._fault and item
                and not self.orchestrator.manual
                and self.orchestrator.owner == 'pan_tilt'
                and 0 <= now-item[0] <= self.cfg.MAX_CONTROL_OBSERVATION_AGE
                and 0 <= now-fields.get('observation_time', float('-inf')) <= self.cfg.MAX_CONTROL_OBSERVATION_AGE
                and item[1] == fields.get('lock_session_id')
                and item[2] == fields.get('target_track_id')
                and item[3][0] == fields.get('pan_tilt_command')
                and self.session_valid(item[1], item[2]))

    def _stop(self):
        try:
            ok, message = self.ptz.stop()
        except Exception as exc:
            ok, message = False, type(exc).__name__
        if not ok:
            self._fault = True
            self.enabled = False
            self.status(f'Auto Pan/Tilt STOP failed: {message}; retrying STOP')
            return False
        self._fault = False
        self.busy = False
        self._ready_after = time.monotonic()+self.cfg.AUTO_PAN_TILT_SETTLE
        self.orchestrator.release('pan_tilt', self.cfg.AUTO_PAN_TILT_SETTLE)
        return True

    def _run(self):
        while True:
            with self._condition:
                if not self._fault:
                    if self._closed:
                        return
                    self._condition.wait(timeout=.03)
                item = self._latest
            if self._fault:
                # Retain exclusive ownership until STOP is acknowledged.
                if not self._stop():
                    time.sleep(.25)
                continue
            if (not item or not self.enabled or item[0] < self._ready_after
                    or time.monotonic()-item[0] > self.cfg.MAX_CONTROL_OBSERVATION_AGE):
                continue
            if not self.orchestrator.acquire('pan_tilt'):
                continue
            fields = dict(motor_owner='pan_tilt', lock_session_id=item[1], target_track_id=item[2],
                          observation_time=item[0], pan_tilt_command=item[3][0])
            try:
                if not self.validate_intent(fields):
                    self.orchestrator.release('pan_tilt')
                    continue
                self.busy = True
                with latency.correlated(**fields):
                    ok, message = self.ptz.command(*item[3])
                if not ok and self.validate_intent(fields):
                    self.enabled = False
                    self.status(f'Auto Pan/Tilt disabled: {message}')
                deadline = time.monotonic()+self.cfg.AUTO_PAN_TILT_PULSE
                with self._condition:
                    while ok and time.monotonic() < deadline and self.validate_intent(fields):
                        self._condition.wait(timeout=min(.02, max(0., deadline-time.monotonic())))
            except Exception as exc:
                self.enabled = False
                self.status(f'Auto Pan/Tilt error: {type(exc).__name__}')
            finally:
                if self.busy:
                    self._stop()

    def close(self, timeout=None):
        with self._condition:
            self._closed = True
            self.enabled = False
            self._latest = None
            self._condition.notify_all()
        self._thread.join(timeout)
        return not self._thread.is_alive()
