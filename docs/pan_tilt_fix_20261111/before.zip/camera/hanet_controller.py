"""HANET adapter using the application's serialized motor execution lane.

Lens coordinates and CNN focus calibrated for Dahua are deliberately unavailable.
"""
import threading
import time

from .hanet_rpc import HanetPTZClient
from .ptz_controller import PTZController, PTZ_STOP
from .zoom_capability import ZoomCapability
from runtime.camera_worker import camera_operation
from runtime.reconnect import ReconnectBackoff
from telemetry import latency


class HanetController(PTZController):
    has_zoom_telemetry = False
    supports_focus = False
    supports_autofocus = False
    supports_pan_tilt = True
    max_speed = 8
    CODES = {'zoom_in': 'kCmdZoomTele', 'zoom_out': 'kCmdZoomWide',
             'pan_left': 'kCmdLeft', 'pan_right': 'kCmdRight',
             'tilt_up': 'kCmdUp', 'tilt_down': 'kCmdDown'}

    def __init__(self, *args, autoconnect=True, rpc_factory=HanetPTZClient, **kwargs):
        super().__init__(*args, autoconnect=False, rpc_factory=rpc_factory, **kwargs)
        self._active_codes = set()
        self._absolute_capability = ZoomCapability(False, 'HANET_POSITION_UNVERIFIED')
        if autoconnect:
            self._poller = threading.Thread(target=self._poll, name='hanet-heartbeat', daemon=True)
            self._poller.start()

    @staticmethod
    def _clamp_speed(speed):
        return max(1, min(8, int(speed)))

    def _connect(self):
        # Called only from the command lane; HTTP and WebSocket never overlap.
        if self._closed.is_set():
            raise RuntimeError('Camera controller is closed')
        if self._rpc is None:
            self._rpc = self._rpc_factory(self.ip, self.port, self.username,
                                          self.password, timeout=self.timeout)
        return self._rpc

    def _poll(self):
        backoff = ReconnectBackoff()
        while not self._closed.is_set():
            try:
                self.read_status()
                backoff.reset()
                delay = 1.
            except Exception as exc:
                self.last_error = f'HANET unavailable ({type(exc).__name__})'
                delay = backoff.next_delay()
            if self._closed.wait(delay):
                return

    @camera_operation
    def read_status(self):
        try:
            self._connect().heartbeat()
        except Exception:
            # Never automatically reconnect/replay motion after a lost START/STOP.
            if not self._active_codes and self._rpc is not None:
                self._rpc.close()
                self._rpc = None
            raise
        self.last_error = None
        return {'connected': True, 'zoom': None, 'focus': None,
                'timestamp': time.monotonic(), 'telemetry_available': False}

    def telemetry(self, max_age=1.):
        return None

    def probe_zoom_capability(self):
        return self._absolute_capability

    @camera_operation
    def command(self, ptz_cmd, speed=None):
        if ptz_cmd == PTZ_STOP:
            return self.stop()
        if ptz_cmd not in self.CODES:
            return False, 'Command unsupported by verified HANET adapter'
        if self._motor_fault:
            return False, 'Motor blocked: retry STOP'
        if self._active_codes:
            ok, message = self.stop()
            if not ok:
                return ok, message
        try:
            rpc = self._connect()
            # Frigate checks movement freshness after dequeue; do the same at I/O.
            fields = latency.context.get()
            if fields.get('lock_session_id') is not None:
                if fields.get('motor_owner') == 'pan_tilt':
                    valid = (ptz_cmd in ('pan_left', 'pan_right', 'tilt_up', 'tilt_down')
                             and fields.get('pan_tilt_command') == ptz_cmd
                             and getattr(self, 'pan_tilt_intent_valid', lambda _: False)(fields))
                else:
                    valid = (self.session_valid(fields['lock_session_id'])
                             and getattr(self, 'zoom_intent_valid', lambda _: True)(fields)
                             and getattr(self, 'zoom_policy_valid', lambda _: True)(fields))
                if not valid:
                    return False, 'Stale camera movement rejected'
            code = self.CODES[ptz_cmd]
            self._active_codes.add(code)  # lost ACK may still mean physical motion
            rpc.motion(code, True, self._clamp_speed(self.speed if speed is None else speed))
            return True, 'HANET acknowledged; physical motion unverified'
        except Exception as exc:
            self.stop()
            return self._failure('HANET command', exc)

    @camera_operation
    def stop(self):
        self.cancel_focus()
        failed = False
        for code in tuple(self._active_codes):
            try:
                self._rpc.motion(code, False, 1)
                self._active_codes.remove(code)
            except Exception:
                failed = True
        self._motor_fault = failed
        return (False, 'HANET STOP unconfirmed') if failed else (True, 'HANET STOP complete')

    def autofocus(self, **kwargs):
        return False, 'HANET autofocus protocol is unverified'

    def move_focus(self, *args, **kwargs):
        return False, 'HANET focus position is unavailable'

    def move_zoom(self, *args, **kwargs):
        return False, 'HANET absolute zoom is unavailable; use directional zoom'

    start_zoom_target = move_zoom
    move_to_zoom_position = move_zoom

    def close(self):
        if getattr(self, '_resources_closed', False):
            return
        # Join the heartbeat before closing the command lane, outside that lane.
        self._closed.set()
        if self._poller is not None:
            self._poller.join(self.timeout * 3 + 1)
        def finish():
            ok, message = self.stop()
            if not ok:
                raise RuntimeError(message)
            if self._rpc is not None:
                self._rpc.close()
                self._rpc = None
        try:
            self._command_worker.call(finish)
        except Exception:
            # Keep the lane available for an explicit STOP/close retry.
            raise
        else:
            self._command_worker.close(self.timeout + 1)
            self._resources_closed = True
