"""HANET JSON-RPC/WebSocket protocol, ported from the workspace camera.py.

This module is self-contained; the PTZ application does not import parent files.
"""
from __future__ import annotations
import base64
import hashlib
import json
import os
import socket
import struct
import time
from uuid import uuid4
import requests

class HanetPTZClient:
    """Client toi thieu cho JSON-RPC/WebSocket cua firmware HANET."""

    def __init__(self, host: str, port: int, username: str, password: str, timeout=5.0):
        self.host = host
        self.port = int(port)
        self.username = username
        self.password = password
        self.timeout = float(timeout)
        self.http_url = f"http://{host}:{port}/mtrpc"
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        self.session_id: str | None = None
        self.heartbeat_interval = 30.0
        self.next_heartbeat = float("inf")
        self._request_id = 0
        self._ws: socket.socket | None = None
        self._ws_buffer = b""
        try:
            self._login()
        except Exception:
            self.session.close()
            raise

    @staticmethod
    def _md5(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def _call(self, method: str, params: dict | None = None) -> dict:
        self._request_id += 1
        payload = {
            "jsonrpc": "2.0",
            "id": self._request_id,
            "method": method,
            "params": params or {},
        }
        response = self.session.post(self.http_url, json=payload, timeout=self.timeout)
        response.raise_for_status()
        message = response.json()
        if message.get("error"):
            raise RuntimeError(f"HANET RPC rejected {method}")
        result = message.get("result")
        if not isinstance(result, dict):
            raise RuntimeError(f"HANET RPC returned invalid {method} response")
        return result

    def _login(self) -> None:
        challenge = self._call(
            "Auth.LoginChallenge",
            {
                "data": {
                    "encrypt_type": "kEncryptDigest",
                    "login_type": "kLoginWeb",
                    "username": self.username,
                }
            },
        )
        digest = (challenge.get("data") or {}).get("digest") or {}
        challenge_session = challenge.get("session_id")
        realm = digest.get("realm")
        nonce = digest.get("nonce")
        qop = digest.get("qop")
        if not all((challenge_session, realm, nonce, qop)):
            raise RuntimeError("HANET login challenge is incomplete")

        nc = "00000001"
        cnonce = str(uuid4())
        uri = "/mtrpc"
        user_hash = self._md5(f"{self.username}:{realm}:{self.password}")
        request_hash = self._md5(f"POST:{uri}")
        response_hash = self._md5(
            f"{user_hash}:{nonce}:{nc}:{cnonce}:{qop}:{request_hash}"
        )
        login_data = {
            "username": self.username,
            "encrypt_type": "kEncryptDigest",
            "login_type": "kLoginWeb",
            "digest": {
                "realm": realm,
                "uri": uri,
                "nonce": nonce,
                "nc": nc,
                "cnonce": cnonce,
                "qop": qop,
                "response": response_hash,
            },
        }
        result = self._call(
            "Auth.Login",
            {"data": login_data, "session_id": challenge_session},
        )
        data = result.get("data") or {}
        self.session_id = data.get("session_id")
        if not self.session_id:
            raise RuntimeError("HANET authentication rejected")

        interval = float(data.get("heartbeat_interval") or 30.0)
        if interval > 10:
            interval = max(1.0, float(int(interval + 2) // 3))
        elif interval > 1:
            interval -= 1
        self.heartbeat_interval = interval
        self.next_heartbeat = time.monotonic() + interval

    def heartbeat(self) -> None:
        if time.monotonic() < self.next_heartbeat:
            return
        self._call("Auth.Heartbeat", {"session_id": self.session_id})
        self.next_heartbeat = time.monotonic() + self.heartbeat_interval

    def _recv_exact(self, size: int) -> bytes:
        while len(self._ws_buffer) < size:
            if self._ws is None:
                raise RuntimeError("WebSocket is closed")
            chunk = self._ws.recv(max(4096, size - len(self._ws_buffer)))
            if not chunk:
                raise RuntimeError("WebSocket connection closed")
            self._ws_buffer += chunk
        result, self._ws_buffer = self._ws_buffer[:size], self._ws_buffer[size:]
        return result

    def _connect_websocket(self) -> None:
        if self._ws is not None:
            return
        connection = socket.create_connection((self.host, self.port), timeout=self.timeout)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            "GET /mtrpcoverwebsocket HTTP/1.1\r\n"
            f"Host: {self.host}:{self.port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            f"Origin: http://{self.host}:{self.port}\r\n\r\n"
        )
        connection.sendall(request.encode("ascii"))
        response = b""
        while b"\r\n\r\n" not in response:
            chunk = connection.recv(4096)
            if not chunk:
                connection.close()
                raise RuntimeError("WebSocket handshake closed")
            response += chunk
            if len(response) > 65536:
                connection.close()
                raise RuntimeError("WebSocket handshake is too large")
        headers, remainder = response.split(b"\r\n\r\n", 1)
        if not headers.startswith(b"HTTP/1.1 101"):
            connection.close()
            raise RuntimeError("WebSocket handshake rejected")
        connection.settimeout(0.5)
        self._ws = connection
        self._ws_buffer = remainder

    def _send_frame(self, payload: bytes, opcode=0x1) -> None:
        if self._ws is None:
            raise RuntimeError("WebSocket is closed")
        mask = os.urandom(4)
        length = len(payload)
        header = bytearray([0x80 | opcode])
        if length < 126:
            header.append(0x80 | length)
        elif length <= 0xFFFF:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))
        header.extend(mask)
        masked = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
        self._ws.sendall(bytes(header) + masked)

    def _recv_frame(self) -> tuple[int, bytes]:
        first, second = self._recv_exact(2)
        opcode = first & 0x0F
        masked = bool(second & 0x80)
        length = second & 0x7F
        if length == 126:
            length = struct.unpack("!H", self._recv_exact(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", self._recv_exact(8))[0]
        mask = self._recv_exact(4) if masked else None
        payload = self._recv_exact(length)
        if mask:
            payload = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
        return opcode, payload

    def _receive_response(self, request_id) -> None:
        deadline = time.monotonic() + self.timeout
        try:
            while time.monotonic() < deadline:
                opcode, payload = self._recv_frame()
                if opcode == 0x9:  # ping
                    self._send_frame(payload, opcode=0xA)
                    continue
                if opcode == 0x8:
                    raise RuntimeError("WebSocket was closed by camera")
                if opcode != 0x1:
                    continue
                message = json.loads(payload.decode("utf-8"))
                if str(message.get("id")) != str(request_id):
                    continue
                if message.get("error") or message.get("result") is False:
                    raise RuntimeError("Camera rejected PTZ command")
                return
            raise TimeoutError("HANET PTZ acknowledgement timed out")
        except socket.timeout:
            raise TimeoutError("HANET PTZ acknowledgement timed out") from None

    def motion(self, code: str, start: bool, speed: int) -> None:
        if not self.session_id:
            raise RuntimeError("HANET session is unavailable")
        self._connect_websocket()
        payload = {
            "id": str(uuid4()),
            "jsonrpc": "2.0",
            "method": "Control.DoPtz",
            "params": {
                "session_id": self.session_id,
                "data": {
                    "cmd": code,
                    "operate": "kOperateStart" if start else "kOperateStop",
                    "channel": 0,
                    "step": max(1, min(8, int(speed))),
                    "preset": 0,
                    "patrol": 0,
                    "preset_name": "",
                },
            },
        }
        self._send_frame(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
        self._receive_response(payload["id"])

    def close(self) -> None:
        connection = self._ws
        if connection is not None:
            try:
                self._send_frame(b"", opcode=0x8)
            except Exception:
                pass
            self._ws = None
            connection.close()
        if self.session_id:
            try:
                self._call("Auth.Logout", {"session_id": self.session_id})
            except Exception:
                pass
        self.session_id = None
        self.session.close()

