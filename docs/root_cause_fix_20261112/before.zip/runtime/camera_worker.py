"""Single bounded execution lane for motor transactions, shared by all controllers.

Supervisors may wait here; inference and Tk only submit to their mailboxes.
Nested operations run inline on the owner thread, avoiding executor deadlocks.
"""
from concurrent.futures import Future
from contextvars import copy_context
from functools import wraps
import queue
import threading
from uuid import uuid4
from telemetry import latency


class CameraCommandWorker:
    def __init__(self):
        self.queue = queue.Queue(maxsize=16)
        self.lock = threading.Lock()
        self.closed = False
        self._stop = threading.Event()
        self.thread = threading.Thread(target=self._run, name='camera-command', daemon=True)
        self.thread.start()

    def call(self, function, *args, **kwargs):
        if threading.current_thread() is self.thread:
            return function(*args, **kwargs)
        future = Future()
        with self.lock:
            if self.closed:
                raise RuntimeError('Camera command worker closed')
            try:
                fields = latency.context.get()
                with latency.correlated(command_id=fields.get('command_id') or 'cmd_'+uuid4().hex):
                    name = function.__name__
                    if name == 'command' and len(args) > 1:
                        name = str(args[1])
                    axis = 'ZOOM' if 'zoom' in name else 'FOCUS' if 'focus' in name else None
                    if axis is not None and 'command_id' not in fields:
                        latency.profiler.event(axis+'_REQUEST_CREATED', source='manual_or_diagnostic')
                    queued = latency.profiler.event('CAMERA_COMMAND_QUEUE_ENTER')
                    self.queue.put_nowait((future, copy_context(), queued, function, args, kwargs))
            except queue.Full:
                latency.profiler.count('dropped_camera_jobs')
                latency.profiler.event('CAMERA_JOB_DROPPED', reason='QUEUE_FULL')
                raise RuntimeError('Camera command queue full') from None
        return future.result()

    def _run(self):
        while True:
            try:
                item = self.queue.get(timeout=0.1)
            except queue.Empty:
                if self._stop.is_set():
                    return
                continue
            future, context, queued, function, args, kwargs = item
            def invoke():
                latency.profiler.elapsed('CAMERA_COMMAND_QUEUE_EXIT', queued, 'camera_command_queue_wait_ms')
                with latency.span('CAMERA_TRANSACTION', 'camera_transaction_ms', operation=function.__name__):
                    return function(*args, **kwargs)
            try:
                future.set_result(context.run(invoke))
            except BaseException as exc:
                future.set_exception(exc)

    def close(self, timeout=5.):
        with self.lock:
            if not self.closed:
                self.closed = True
                # A full queue must never block shutdown while holding the lock.
                # The worker drains accepted transactions before exiting.
                self._stop.set()
        if threading.current_thread() is not self.thread:
            self.thread.join(timeout)
        return not self.thread.is_alive()


def camera_operation(function):
    @wraps(function)
    def run(self, *args, **kwargs):
        # Unit/diagnostic adapters can still instantiate with autoconnect=False.
        if function.__name__ == 'stop':
            self.cancel_focus()  # interrupt a long focus task before waiting in its queue
        worker = self._command_worker
        return worker.call(function, self, *args, **kwargs)
    return run
