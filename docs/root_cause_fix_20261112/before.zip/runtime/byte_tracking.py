"""ByteTrack motion association; native IDs are never treated as identity evidence."""
from types import SimpleNamespace
import numpy as np
from ultralytics.trackers.byte_tracker import BYTETracker, STrack


class Detections:
    def __init__(self, rows):
        self.rows = rows
        self.conf = rows[:, 4]
        self.cls = np.zeros(len(rows))
        self.xyxy = rows[:, :4]
        self.xywh = self.xyxy.copy()
        self.xywh[:, :2] = (self.xyxy[:, :2] + self.xyxy[:, 2:]) / 2
        self.xywh[:, 2:] -= self.xyxy[:, :2]
    def __len__(self):
        return len(self.rows)
    def __getitem__(self, index):
        return Detections(self.rows[index])


class IndexedByteTracker(BYTETracker):
    def init_track(self, results, img=None):
        # Preserve original indexes through ByteTrack's high/low score partitions.
        return [STrack(np.r_[box, row[5]], score, 0)
                for box, row, score in zip(results.xywh, results.rows, results.conf)]


class ByteTrackPersonTracker:
    def __init__(self, cfg):
        self.cfg = cfg
        self.tracker = IndexedByteTracker(SimpleNamespace(
            track_high_thresh=cfg.PERSON_CONF_THRESHOLD,
            track_low_thresh=cfg.BYTE_TRACK_LOW_THRESHOLD,
            new_track_thresh=cfg.PERSON_CONF_THRESHOLD,
            track_buffer=round(30 * cfg.REID_LOST_GRACE_SEC),
            match_thresh=.8, fuse_score=False), frame_rate=cfg.AI_MAX_FPS)
        self.ids = {}
        self.next_id = 0
        self.last_received = None

    def reset(self):
        self.tracker.reset()
        self.ids.clear()
        self.last_received = None

    def update(self, persons, received):
        if self.last_received is not None:
            if received <= self.last_received:
                return []
            if received-self.last_received > self.cfg.REID_LOST_GRACE_SEC:
                self.reset()
        self.last_received = received
        rows = np.asarray([[*p['bbox'], p.get('confidence', 1.), i]
                           for i, p in enumerate(persons)], dtype=np.float32).reshape(-1, 6)
        output = []
        for track in self.tracker.update(Detections(rows)):
            native, index = int(track[4]), int(track[-1])
            if native not in self.ids:
                self.next_id += 1
                self.ids[native] = self.next_id
            person = persons[index]
            person['track_id'] = self.ids[native]
            output.append(person)
        return output
